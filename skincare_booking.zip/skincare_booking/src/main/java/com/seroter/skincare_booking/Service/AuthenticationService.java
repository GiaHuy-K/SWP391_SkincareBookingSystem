package com.seroter.skincare_booking.Service;

import com.seroter.skincare_booking.entity.Account;
import com.seroter.skincare_booking.entity.request.AccountRequest;
import com.seroter.skincare_booking.enums.RoleEnum;
import com.seroter.skincare_booking.repository.AuthenticationRepository;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService implements UserDetailsService {

    @Autowired
    AuthenticationRepository authenticationRepository;
    @Autowired
    PasswordEncoder passwordEncoder;

    public Account register(@Valid AccountRequest accountRequest) {
//        // => pass vòng validation
//        boolean isDuplicate = false;
//        if(isDuplicate){
//            // => báo lỗi
//            throw new DuplicateEntity("Duplicate!");
//        }else{
//            // lưu vào database
//            return account;
//        }
        Account account = new Account();

        account.setUsername(accountRequest.getUsername());
        account.setRoleEnum(RoleEnum.CUSTOMER);
        account.setPassword(passwordEncoder.encode(accountRequest.getPassword()));
        account.setFullName(accountRequest.getFullName());
        account.setEmail(accountRequest.getEmail());

        Account newAccount = authenticationRepository.save(account);
        return newAccount;
    }

    public Account login() {


        return null;
    }


    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        return null;
    }
}
