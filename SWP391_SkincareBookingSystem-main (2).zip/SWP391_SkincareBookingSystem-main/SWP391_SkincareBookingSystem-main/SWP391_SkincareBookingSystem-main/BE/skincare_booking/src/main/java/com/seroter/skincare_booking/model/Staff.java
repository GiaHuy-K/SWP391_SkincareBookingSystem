package com.seroter.skincare_booking.model;

public class Staff {

    public String StaffID;
    public String FullName;
    public String BirthDate;
    public String Gender;
    public String PhoneNumber;
    public String Email;
    public String Address;
    public String Role;
    public String WorkSchedule;
}
