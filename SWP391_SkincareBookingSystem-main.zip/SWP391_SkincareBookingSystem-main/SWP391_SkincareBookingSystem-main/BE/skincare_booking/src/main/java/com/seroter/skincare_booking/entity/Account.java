package com.seroter.skincare_booking.entity;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class Account {
    long id;

    @Email (message = "Invalid Email")
    String email;

    @Pattern(regexp = "84|0[3|5|7|8|9]) + (\\d{8})", message = "Invalid phone!")
    String phone;

    @Size(min = 6, message = "Password must be at least 6 character!")
    String password;
}
