package com.seroter.skincare_booking.enums;

public enum RoleEnum {
    STAFF,
    CUSTOMER,
    MANAGER,
    SKIN_THERAPIST;
}
