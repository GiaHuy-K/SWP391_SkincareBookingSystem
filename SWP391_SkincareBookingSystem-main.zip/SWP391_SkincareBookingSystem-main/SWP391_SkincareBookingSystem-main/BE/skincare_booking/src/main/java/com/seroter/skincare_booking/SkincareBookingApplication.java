package com.seroter.skincare_booking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkincareBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkincareBookingApplication.class, args);
	}

}
