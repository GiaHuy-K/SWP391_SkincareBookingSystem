package com.seroter.skincare_booking.Service;

import com.seroter.skincare_booking.entity.Account;
import com.seroter.skincare_booking.exception.DuplicateEntity;
import com.seroter.skincare_booking.repository.AuthenticationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AuthenticationService {

    @Autowired
    AuthenticationRepository authenticationRepository;

    public Account register (Account account){
//        // => pass vòng validation
//        boolean isDuplicate = false;
//        if(isDuplicate){
//            // => báo lỗi
//            throw new DuplicateEntity("Duplicate!");
//        }else{
//            // lưu vào database
//            return account;
//        }

        Account newAccount = authenticationRepository.save(account);
        return newAccount;
    }

    public Account login(){
        return null;
    }
}
