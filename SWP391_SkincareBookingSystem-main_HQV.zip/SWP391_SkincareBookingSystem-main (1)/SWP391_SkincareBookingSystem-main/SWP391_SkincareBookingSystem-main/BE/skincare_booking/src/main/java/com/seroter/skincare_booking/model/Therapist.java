package com.seroter.skincare_booking.model;

public class Therapist {
    public String TherapistID;
    public String FullName;
    public String BirthDate;
    public String Gender;
    public String PhoneNumber;
    public String Email;
    public String Address;
    public String Specialization;
    public String Experience;
    public String WorkSchedule;
}
